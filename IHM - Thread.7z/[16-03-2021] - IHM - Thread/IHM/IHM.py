#! /usr/bin/env python
#  -*- coding: utf-8 -*-

#============================== Importar bibliotecas com checagem de erro ==============================
import sys

try:
    import os
except ImportError:
    import os

try:
    import tkinter as tk
except ImportError:
    import tkinter as tk

try:
    import ttk
    py3 = False
except ImportError:
    import tkinter.ttk as ttk
    py3 = True

try:
    import datetime
except ImportError:
    import datetime

try:
    import IHM_support
except ImportError:
    import IHM_support
    
try:
    from tkinter import messagebox
except ImportError:
    from tkinter import messagebox

try:
    from tkinter import StringVar
except ImportError:
    from tkinter import StringVar

try:
    from docx import Document
except ImportError:
    from docx import Document

try:
    from docx.shared import Mm
except ImportError:
    from docx.shared import Mm

try:
    import numpy
except ImportError:
    import numpy
    
try: 
    import pandas as pd
except ImportError:
    import pandas as pd

try:
    import math
except ImportError:
    import math

try:
    import matplotlib.pyplot as plt
except ImportError:
    import matplotlib.pyplot as plt

try:
    import time as delay
except ImportError:
    import time as delay
    
try:
    import board
except ImportError:
    import board

try:
    from digitalio import DigitalInOut
except ImportError:
    from digitalio import DigitalInOut
    
try: 
    from adafruit_vl53l0x import VL53L0X
except ImportError:
    from adafruit_vl53l0x import VL53L0X

try:
    import statistics as stat
except ImportError:
    import statistics as stat    

try:
    from pykalman import KalmanFilter
except ImportError:
    from pykalman import KalmanFilter

try:
    import threading
except ImportError:
    import threading

#============================== Variáveis para IHM ==============================
index = 0
vel_prec = 0
nome_res = ""
empresa_res = ""
nome_sol = ""
empresa_sol = ""
codigo_prod = ""
descricao_prod = ""
data_inspec = ""
comprimento = 0.0
diametro = 0.0
tolerancia = 0.0
tamanho_DF = 0
count_Passo = 2 # Quantidade de passos do motor responsável pelo giro
count_Camada = 10  # Quantidade de camadas a percorrer
camada_util = 7
Aux_Camada = count_Camada
Aux_Passo = count_Passo

#============================== Inicialização da IHM ==============================
def vp_start_gui():
    '''Starting point when module is the main routine.'''
    global val, w, root
    root = tk.Tk()
    IHM_support.set_Tk_var()
    top = tpl_JanelaPrincipal(root)
    IHM_support.init(root, top)
    root.mainloop()
    
w = None
def create_tpl_JanelaPrincipal(rt, *args, **kwargs):
    '''Starting point when module is imported by another module.
       Correct form of call: 'create_tpl_JanelaPrincipal(root, *args, **kwargs)' .'''
    global w, w_win, root
    #rt = root
    root = rt
    w = tk.Toplevel (root)
    IHM_support.set_Tk_var()
    top = tpl_JanelaPrincipal (w)
    IHM_support.init(w, top, *args, **kwargs)
    return (w, top)

#============================== Fechamento da IHM ==============================

def destroy_tpl_JanelaPrincipal():
    global w
    w.destroy()
    w = None
    
#============================== Execução principal da IHM ==============================
class tpl_JanelaPrincipal():
    def __init__(self, top=None):
        
        def Ler_Sensor():
            print('1')
            global count_Camada, camada_util, count_Passo, Aux_Camada, Aux_Passo;
            
            #======================== Variáveis para sensor ========================      
            #NORMAL_MODE = 33000 # Peíodo de pulsação do laser = 33 ms
            #HIGH_SPEED = 20000 # Peíodo de pulsação do laser reduzido = 33 ms
            HIGH_ACCURACY = 200000 # Peíodo de pulsação do laser incrementado = 200 ms
            vl53 = [] # Declararação do atributo sensor
            
            #======================= Variáveis para leitura ========================
            count_Leitura = 10 # Número de vezes que cada sensor fará a leitura para média
            offset_S1 = 0
            offset_S2 = 1
            offset_S3 = 2

            Aux_Leitura = count_Leitura
            ajuste_count_Passo = count_Passo
            ajuste_count_Camada = count_Camada
            leituras_S1 = []
            leituras_S2 = []
            leituras_S3 = []
            lista_Media_S1 = []
            lista_Media_S2 = []
            lista_Media_S3 = []
            lista_count_Passo = []
            lista_count_Camada = []
            df_data = pd.DataFrame()
            
            #===================== Definição dos limites de leitura ======================
            S1_inicial = Aux_Camada - offset_S1
            S1_final = Aux_Camada - camada_util - offset_S1
            S2_inicial = Aux_Camada - offset_S2
            S2_final = Aux_Camada - camada_util - offset_S2
            S3_inicial = Aux_Camada - offset_S3
            S3_final = Aux_Camada - camada_util - offset_S3
            
            #===================== Instância Filtro de Kalman ======================
            kf = KalmanFilter(transition_matrices = [1],
                              observation_matrices = [1],
                              initial_state_mean = diametro,
                              initial_state_covariance = 1,
                              observation_covariance = .01,
                              transition_covariance = .00001)
            
            #======================= Setup dos pinos I2C e digitais ========================
            i2c_address = board.I2C() # Recebe o endereço I2C da placa
            delay.sleep(0.5)
            xshut = [DigitalInOut(board.D17), DigitalInOut(board.D22), DigitalInOut(board.D27)] # Seta os pinos digitais para controle
            delay.sleep(0.2)
            
            #======================= Desligamento dos sensores =======================
            
            for power_pin in xshut:
                power_pin.switch_to_output(value=False)
                delay.sleep(0.2)
            
            '''
                Teste de hardware e pareamento dos sensores
            '''

            for i, power_pin in enumerate(xshut):
                power_pin.value = True # Ligando o sensor número 'i'
                vl53.insert(i, VL53L0X(i2c_address)) # Endereçamento do sensor 'i'
                if i < len(xshut) - 1:
                    vl53[i].set_address(i + 0x30) # Declaração do endereçamento caso o mesmo não esteja em uso
                    delay.sleep(0.5) # Delay para configuração (Mínimo de 0.5)
                    vl53[i].measurement_timing_budget = HIGH_ACCURACY # Declaração do modo de operação
                    delay.sleep(0.5) # Delay para configuração (Mínimo de 0.5)
            
            #======================= Void Loop ========================
            
            print("LOOP")
            # While das camadas
            while count_Camada:
                #print('\nCamada: {}\n'.format(count_Camada))
                # While dos Passos
                while count_Passo:
                    #print('\nPasso: {}\n'.format(count_Passo))
                    # While das leituras
                    while count_Leitura:
                        for index, sensor in enumerate(vl53):
                            # Apresentação das leituras em tela
                            #print('Sensor {} Range: {}mm'.format(index + 1, sensor.range))
                            
                            # Separação dos dados lidos por sensor
                            # Sensor 1
                            if ((index + 1) == 1) and (count_Camada < S1_inicial) and (count_Camada >= S1_final):
                                leituras_S1.append(sensor.range)
                            # Sensor 2
                            if (index + 1) == 2 and (count_Camada < S2_inicial) and (count_Camada >= S2_final): 
                                leituras_S2.append(sensor.range)
                            # Sensor 3
                            if (index + 1) == 3 and (count_Camada < S3_inicial) and (count_Camada >= S3_final):
                                leituras_S3.append(sensor.range)
                                                                
                        # Decrementar variável de trava do while
                        count_Leitura -= 1
                    
                    # Fim do while das leituras
                    
                    # Transformação do array do S1, S2 e S3 em Serie para utilizar o filtro de kalman
                    leituras_S1_S = pd.Series(leituras_S1)
                    leituras_S2_S = pd.Series(leituras_S2)
                    leituras_S3_S = pd.Series(leituras_S3)
                
                    # Aplica o filtro de kalman para S1, S2 e S3 em cada condicional
                    # Aplica Médias móveis e transição para Serie para S1, S2 e S3 em cada condicional
                    # Cálculo das médias do sensor S1, S2 e S3 em cada condicional
                    # Adição da média de S1, S2 e S3 as listas correspondentes 
                    # Limpeza das listas e séries dos sensores 1, 2 e 3
                    
                    if (count_Camada < S1_inicial) and (count_Camada >= S1_final):
                        state_mean_S1, _ = kf.filter(leituras_S1_S.values)
                        filtro_S1_S = pd.Series(state_mean_S1.flatten(), index=leituras_S1_S.index)
                        media_S1 = stat.mean(filtro_S1_S)
                        lista_Media_S1.append(media_S1)
                        media_S1 = 0
                        leituras_S1.clear()
                        state_mean_S1 = []
                        filtro_S1_S.drop(axis=0, inplace=True, index=filtro_S1_S.index)
                        
                    if (count_Camada < S2_inicial) and (count_Camada >= S2_final):
                        state_mean_S2, _ = kf.filter(leituras_S2_S.values)
                        filtro_S2_S = pd.Series(state_mean_S2.flatten(), index=leituras_S2_S.index)
                        media_S2 = stat.mean(filtro_S2_S)
                        lista_Media_S2.append(media_S2)
                        media_S2 = 0
                        leituras_S2.clear()
                        state_mean_S2 = []
                        filtro_S2_S.drop(axis=0, inplace=True, index=filtro_S2_S.index)
                    
                    if (count_Camada < S3_inicial) and (count_Camada >= S3_final):
                        state_mean_S3, _ = kf.filter(leituras_S3_S.values)
                        filtro_S3_S = pd.Series(state_mean_S3.flatten(), index=leituras_S3_S.index)
                        media_S3 = stat.mean(filtro_S3_S)
                        lista_Media_S3.append(media_S3)
                        media_S3 = 0
                        leituras_S3.clear()
                        state_mean_S3 = []
                        filtro_S3_S.drop(axis=0, inplace=True, index=filtro_S3_S.index)            
                   
                    # Salva na lista correspondente em qual passo o sistema se encontra
                    lista_count_Passo.append(ajuste_count_Passo - count_Passo + 1)
    
                    # Salva na lista correspondente em qual camada o sistema se encontra
                    lista_count_Camada.append(ajuste_count_Camada - count_Camada + 1)
        
                    # Decrementar variável de trava do while dos passos
                    count_Passo -= 1
        
                    count_Leitura = Aux_Leitura
                    
                # Fim do while dos passos
                
                # Decrementar variável de trava do while da camada
                count_Camada -= 1
                
                count_Passo = Aux_Passo
                
                '''
                    Salva os dados necessários para um dataframe    
                '''
            
                lista_Camada_df = pd.DataFrame(lista_count_Camada, columns=['Camada'])
                lista_Passo_df = pd.DataFrame(lista_count_Passo, columns=['Passo'])
                lista_Media_S1_df = pd.DataFrame(lista_Media_S1, columns=['Media S1'])
                lista_Media_S2_df = pd.DataFrame(lista_Media_S2, columns=['Media S2'])
                lista_Media_S3_df = pd.DataFrame(lista_Media_S3, columns=['Media S3'])
            
                df_data = lista_Camada_df
                df_data = df_data.join(lista_Passo_df)
                df_data = df_data.join(lista_Media_S1_df)
                df_data = df_data.join(lista_Media_S2_df)
                df_data = df_data.join(lista_Media_S3_df)
                
                '''
                    Salva um dataframe para excel
                '''
                Valor_Pbar = (100 - (100*count_Camada/Aux_Camada))
                self.pgb_Status.configure(value = Valor_Pbar)
                
            # Cria o parametro para escrita
            writer = pd.ExcelWriter('/home/pi/Downloads/IHM - Thread/IHM/leitura.xlsx', engine = 'xlsxwriter')
                
            # Salva o arquivo para excel
            df_data.to_excel(writer, index = True, sheet_name = 'leituras')
                
            # Salva a planilha
            workboot = writer.bookworksheet = writer.sheets['leituras']
            writer.save()

            self.btn_verTabela.configure(state="normal")        
        
        def Tabela_Imagem():
            global tamanho_DF, contador_Peças_Dentro, contador_Peças_Acima, contador_Peças_Abaixo, Porcentagem_Dentro, Porcentagem_Acima, Porcentagem_Abaixo;

            #============================== Variáveis para análise e plot ==============================
            print("Teste")
            Angulo_Motor_Graus = 1.8
            Angulo_Motor_Rad = math.radians(Angulo_Motor_Graus)
            Camada_mm = 10
            Raio_Padrao = 200.0 - (diametro/2)
            Tolerancia = tolerancia
            RaioToleranciaPositiva = Raio_Padrao + Tolerancia
            RaioToleranciaNegativa = Raio_Padrao - Tolerancia
            contador_Peças_Dentro = 0
            contador_Peças_Acima = 0
            contador_Peças_Abaixo = 0
            Porcentagem_Dentro = 0
            Porcentagem_Acima = 0
            Porcentagem_Abaixo = 0
                      
            df = pd.read_excel('leitura.xlsx')
            
            df['Média'] = 0
            df['Valor X'] = 0
            df['Valor Y'] = 0
            df['Valor Z'] = 0
            df['Padrão Coordenadas Cilindricass X'] = 0
            df['Padrão Coordenadas Cilindricass Y'] = 0
            df['Dispersão X'] = 0
            df['Dispersão Y'] = 0
            df['Dispersão Média'] = 0
            tamanho_DF = len(df)

            for i, row in df.iterrows():
                df.loc[i,'Média'] =  (df.loc[i,'Media S1'] + df.loc[i,'Media S2'] + df.loc[i,'Media S3']) / 3
                df.loc[i,'Valor X'] = df.loc[i,'Média'] * math.cos(df.loc[i,'Passo'] * Angulo_Motor_Rad)   
                df.loc[i,'Valor Y'] = df.loc[i,'Média'] * math.sin(df.loc[i,'Passo'] * Angulo_Motor_Rad)
                df.loc[i,'Valor Z'] = df.loc[i,'Camada'] * Camada_mm
                df.loc[i,'Padrão Coordenadas Cilindricass X'] =  Raio_Padrao * math.cos(df.loc[i,'Passo'] * Angulo_Motor_Rad)
                df.loc[i,'Padrão Coordenadas Cilindricass Y'] =  Raio_Padrao * math.sin(df.loc[i,'Passo'] * Angulo_Motor_Rad)
                df.loc[i,'Dispersão X'] = (df.loc[i,'Padrão Coordenadas Cilindricass X'] - df.loc[i,'Valor X']) ** 2
                df.loc[i,'Dispersão Y'] = (df.loc[i,'Padrão Coordenadas Cilindricass Y'] - df.loc[i,'Valor Y']) ** 2
                df.loc[i,'Dispersão Média'] = df.loc[i,'Média'] - Raio_Padrao
                
                if df.loc[i,'Média'] < RaioToleranciaPositiva and df.loc[i,'Média'] > RaioToleranciaNegativa:
                    contador_Peças_Dentro += 1
                
                elif df.loc[i,'Média'] > RaioToleranciaPositiva:
                    contador_Peças_Acima += 1
                 
                elif df.loc[i,'Média'] < RaioToleranciaNegativa:
                    contador_Peças_Abaixo += 1   
            
            Porcentagem_Dentro = (contador_Peças_Dentro/tamanho_DF)*100.0
            Porcentagem_Acima = (contador_Peças_Acima/tamanho_DF)*100.0
            Porcentagem_Abaixo = (contador_Peças_Abaixo/tamanho_DF)*100.0
            
            fig = plt.figure(figsize=(10, 10))
            ax = fig.add_subplot(111, projection='3d')
            
            x = df['Valor X'].tolist()
            y = df['Valor Y'].tolist()
            z = df['Valor Z'].tolist()
            cor = df['Dispersão Média'].tolist()
            
            ax.scatter(x, y, z, c=cor, cmap='spring', marker='o')
            
            plt.savefig('resultado.png', dpi = 300, orientation='portrait', transparent=False)
            
            os.system('sudo libreoffice -o leitura.xlsx')
            plt.show()
    
            self.btn_verRelatorio.configure(state="normal")
            
        def Relatorio():
            print("Amigo estou aqui!")
            # ============================== Área do relatório ==============================
            document = Document()
            
            document.add_heading('Relatório de Inspeção', 0) #Adiciona o cabeçalho
            
            p = document.add_paragraph('Relatório de Inspeção realizado em: ' + data_inspec + '\n')
            p = document.add_paragraph('Esse relatório fora executado por ' + nome_res + ' em nome de ' + empresa_res)
            
            document.add_heading('Informações da inspeção', level=1)
            
            p = document.add_paragraph('\n' + 'Nome do Solicitante: ' + nome_sol)
            p = document.add_paragraph('Empresa do Solicitante: ' + empresa_sol)
            p = document.add_paragraph('Código do produto analisado: ' + codigo_prod)
            p = document.add_paragraph('Descrição do produto: ' + descricao_prod)
            p = document.add_paragraph('Comprimento informado: ' + str(comprimento) + ' mm')
            p = document.add_paragraph('Diâmetro de referência: ' + str(diametro) + ' mm')
            p = document.add_paragraph('Tolerância especificada: ±' + str(tolerancia) + ' mm' + '\n\n')
            
            document.add_page_break()
            
            document.add_heading('Resultados do ensaio', level=1)
            p = document.add_paragraph('\n' + 'Nessa seção serão apresentados os resultados dos ensaios realizados.\n\n')
            p = document.add_paragraph('Foram análisados ' + str(tamanho_DF) + ' pontos. Dentre eles, haviam: ' + str(contador_Peças_Dentro) + ' pontos dentro da tolerância especificada, representando ' + str(round(Porcentagem_Dentro, 2)) + ' %, haviam também ' + str(contador_Peças_Acima) + ' pontos acima da tolerância, representando ' + str(round(Porcentagem_Acima, 2)) + ' %, e ' + str(contador_Peças_Abaixo) + ' abaixo, representado ' + str(round(Porcentagem_Abaixo,2)) + ' %. \n\n')
            
            document.add_heading('Núvem de pontos', level=2)
            
            document.add_picture('resultado.png', width=Mm(150), height=Mm(150))

            document.save('relatório.docx')
            
            os.system('sudo libreoffice -o relatório.docx')

            self.btn_verTabela.configure(state="disabled")
            self.btn_verRelatorio.configure(state="disabled")
        
        # ============================ Área da análise e plot ===========================        
        def RunSensor():
            self.pgb_Status.configure(value=0)
            threading.Thread(target=Ler_Sensor).start()
        
        def RunTabela():         
            threading.Thread(target=Tabela_Imagem).start()
        
        def RunRelatorio():
            threading.Thread(target=Relatorio).start()
        
        #============================== Confirmação antes de fechar a IHM ==============================
        def on_closing():
            if messagebox.askokcancel("Sair?", "Tem certeza que deseja sair?", icon='warning'):
                root.destroy()

        top.protocol("WM_DELETE_WINDOW", on_closing) #Protocolo que chama o teste de fechamento
        
        #==================== Função responsável por coletar o valor dos radio buttons ====================
        def getValue():
            global vel_prec
            global count_Camada
            global camada_util
           
            vel_prec = IHM_support.Vel.get()
            print(vel_prec)
            if vel_prec == 1:
                count_camada = 10 #valor padrao 96 
                camada_util = 7 #valor padrao 50

            elif vel_prec == 2:
                count_camada = 48
                camada_util = 25
        
        #============================== Função principal da IHM ==============================
        def Operacao():
            resposta = tk.messagebox.askquestion("Confirmar?", "Tem certeza que deseja prosseguir?", icon='warning')         
           
            if resposta == 'yes':
                global index, nome_res, empresa_res, nome_sol, empresa_sol, codigo_prod, descricao_prod, data_inspec, comprimento, diametro, tolerancia
                
                nome_res = nResponsavel.get()               
                empresa_res = eResponsavel.get()
                nome_sol = nSolicitante.get()
                empresa_sol = eSolicitante.get()
                codigo_prod = cProduto.get()
                descricao_prod = dProduto.get()
                data_inspec = dInspecao.get()
                comprimento = Comprimento.get().replace(',','.')
                diametro = Diametro.get().replace(',','.')
                tolerancia = Tolerancia.get().replace(',','.')
    
                try:
                    str(nome_res)
                    str(empresa_res)
                    str(nome_sol)
                    str(codigo_prod)
                    str(descricao_prod)

                    day, month, year = map(int, data_inspec.split('/'))
                    data = datetime.date(year, month, day)       
                    
                    float(comprimento)
                    float(diametro)
                    float(tolerancia)
                    
                except ValueError:
                    tk.messagebox.showerror("Erro de preenchimendo", "Verifique os campos e tente novamente")
                    return Operacao
                
                #============================== Teste para toggle do botão iniciar ==============================
                
                if index == 1:
                    self.btn_modoOperacao.configure(background="#00c800")
                    self.btn_modoOperacao.configure(text='''Iniciar''')
                    self.lbl_Status.configure(text='''Status: Stand-by''')            

                    self.txt_nResponsavel.configure(state='normal')
                    self.txt_eResponsavel.configure(state='normal')
                    self.txt_nSolicitante.configure(state='normal')
                    self.txt_eSolicitante.configure(state='normal')
                    self.txt_cProduto.configure(state='normal')
                    self.txt_dProduto.configure(state='normal')
                    self.txt_dInspecao.configure(state='normal')
                    self.txt_Comprimento.configure(state='normal')
                    self.txt_Diametro.configure(state='normal')
                    self.txt_Tolerancia.configure(state='normal')    
                    self.rb_Velocidade.configure(state='normal')
                    self.rb_Precisao.configure(state='normal')
                    
                    nome_res = nResponsavel.set("")               
                    empresa_res = eResponsavel.set("")
                    nome_sol = nSolicitante.set("")
                    empresa_sol = eSolicitante.set("")
                    codigo_prod = cProduto.set("")
                    descricao_prod = dProduto.set("")
                    data_inspec = dInspecao.set("")
                    comprimento = Comprimento.set("")
                    diametro = Diametro.set("")
                    tolerancia = Tolerancia.set("")
                    
                    index = 0
                else:
                    self.btn_modoOperacao.configure(background="#c80000")
                    self.btn_modoOperacao.configure(text='''Parar''')
                    self.lbl_Status.configure(text='''Status: Em Processo''')
                    
                    self.txt_nResponsavel.configure(state='readonly')
                    self.txt_eResponsavel.configure(state='readonly')
                    self.txt_nSolicitante.configure(state='readonly')
                    self.txt_eSolicitante.configure(state='readonly')
                    self.txt_cProduto.configure(state='readonly')
                    self.txt_dProduto.configure(state='readonly')
                    self.txt_dInspecao.configure(state='readonly')
                    self.txt_Comprimento.configure(state='readonly')
                    self.txt_Diametro.configure(state='readonly')
                    self.txt_Tolerancia.configure(state='readonly')    
                    self.rb_Velocidade.configure(state='disabled')
                    self.rb_Precisao.configure(state='disabled')
                    
                    comprimento = abs(float(comprimento))
                    diametro = abs(float(diametro))
                    tolerancia = abs(float(tolerancia))
                    
                    RunSensor()
                    
                    print("TESTE")
                    self.btn_verTabela.configure(state="disabled")
                    self.btn_verRelatorio.configure(state="disabled")
                   
                    index = 1
                    
            else:
                return Operacao

        #===================== Classes e atributos da janela principal e seus objetos ====================
        '''Esta classe configura e preenche a janela principal.'''
            
        _bgcolor = '#d9d9d9'  # X11 color: 'gray85'
        _fgcolor = '#000000'  # X11 color: 'black'
        _compcolor = '#d9d9d9' # X11 color: 'gray85'
        _ana2color = '#ececec' # Closest X11 color: 'gray92'
        self.style = ttk.Style()
        if sys.platform == "win32":
            self.style.theme_use('winnative')
        self.style.configure('.',background=_bgcolor)
        self.style.configure('.',foreground=_fgcolor)
        self.style.map('.',background=
            [('selected', _compcolor), ('active',_ana2color)])

        # Define o tamanho e centra a janela ao iniciar
        largura = 1280
        altura = 720
        largura_screen = top.winfo_screenwidth()
        altura_screnn = top.winfo_screenheight() 
        
        posx = largura_screen/2 - largura/2
        posy = altura_screnn/2 - altura/2
        
        top.geometry("%dx%d+%d+%d" % (largura, altura, posx, posy))
        top.minsize(1000, 500)
        top.maxsize(1540, 845)
        top.resizable(1,  1)
        top.title("Sistema de Inspeção de Peças Cilíndricas")
        top.configure(background="#ffffff")
        top.configure(cursor="arrow")
        
        #top.iconbitmap("imagens/icone.ico") 
        
        # Variáveis para receber os valores das Entrys
        nResponsavel = StringVar()
        eResponsavel = StringVar()
        nSolicitante = StringVar()
        eSolicitante = StringVar()
        cProduto = StringVar()
        dProduto = StringVar()
        dInspecao = StringVar()
        Comprimento = StringVar()
        Diametro = StringVar()
        Tolerancia = StringVar()
        IHM_support.Vel.set("1")

        #===================== Classes e atributos da dos objetos da janela principal ====================

        self.menubar = tk.Menu(top,font="TkMenuFont",bg=_bgcolor,fg=_fgcolor)
        top.configure(menu = self.menubar)

        self.Label1 = tk.Label(top)
        self.Label1.place(relx=0.009, rely=0.012, height=38, width=299)
        self.Label1.configure(background="#ffffff")
        self.Label1.configure(disabledforeground="#a3a3a3")
        self.Label1.configure(font="-family {Arial} -size 20 -weight bold")
        self.Label1.configure(foreground="#000000")
        self.Label1.configure(text='''Dados de Usuário:''')

        self.Label2 = tk.Label(top)
        self.Label2.place(relx=0.505, rely=0.012, height=38, width=318)
        self.Label2.configure(background="#ffffff")
        self.Label2.configure(disabledforeground="#a3a3a3")
        self.Label2.configure(font="-family {Arial} -size 20 -weight bold")
        self.Label2.configure(foreground="#000000")
        self.Label2.configure(text='''Modo de Operação:''')

        self.lbl_Status = tk.Label(top)
        self.lbl_Status.place(relx=0.467, rely=0.304, height=46, width=418)
        self.lbl_Status.configure(background="#ffffff")
        self.lbl_Status.configure(disabledforeground="#a3a3a3")
        self.lbl_Status.configure(font="-family {Arial} -size 24 -weight bold")
        self.lbl_Status.configure(foreground="#000000")
        self.lbl_Status.configure(text='''Status: Stand-by''')

        self.Label3 = tk.Label(top)
        self.Label3.place(relx=0.015, rely=0.092, height=20, width=200)
        self.Label3.configure(anchor='w')
        self.Label3.configure(background="#ffffff")
        self.Label3.configure(disabledforeground="#a3a3a3")
        self.Label3.configure(font="-family {Arial} -size 10")
        self.Label3.configure(foreground="#000000")
        self.Label3.configure(justify='left')
        self.Label3.configure(text='''Nome do Responsável:''')

        self.Label4 = tk.Label(top)
        self.Label4.place(relx=0.015, rely=0.173, height=20, width=200)
        self.Label4.configure(activebackground="#f9f9f9")
        self.Label4.configure(activeforeground="black")
        self.Label4.configure(anchor='w')
        self.Label4.configure(background="#ffffff")
        self.Label4.configure(disabledforeground="#a3a3a3")
        self.Label4.configure(font="-family {Arial} -size 10")
        self.Label4.configure(foreground="#000000")
        self.Label4.configure(highlightbackground="#d9d9d9")
        self.Label4.configure(highlightcolor="black")
        self.Label4.configure(justify='left')
        self.Label4.configure(text='''Empresa Responsável:''')

        self.Label5 = tk.Label(top)
        self.Label5.place(relx=0.015, rely=0.254, height=20, width=199)
        self.Label5.configure(activebackground="#f9f9f9")
        self.Label5.configure(activeforeground="black")
        self.Label5.configure(anchor='w')
        self.Label5.configure(background="#ffffff")
        self.Label5.configure(disabledforeground="#a3a3a3")
        self.Label5.configure(font="-family {Arial} -size 10")
        self.Label5.configure(foreground="#000000")
        self.Label5.configure(highlightbackground="#d9d9d9")
        self.Label5.configure(highlightcolor="black")
        self.Label5.configure(justify='left')
        self.Label5.configure(text='''Nome do Solicitante:''')

        self.Label6 = tk.Label(top)
        self.Label6.place(relx=0.015, rely=0.335, height=20, width=200)
        self.Label6.configure(activebackground="#f9f9f9")
        self.Label6.configure(activeforeground="black")
        self.Label6.configure(anchor='w')
        self.Label6.configure(background="#ffffff")
        self.Label6.configure(disabledforeground="#a3a3a3")
        self.Label6.configure(font="-family {Arial} -size 10")
        self.Label6.configure(foreground="#000000")
        self.Label6.configure(highlightbackground="#d9d9d9")
        self.Label6.configure(highlightcolor="black")
        self.Label6.configure(justify='left')
        self.Label6.configure(text='''Empresa Solicitante:''')

        self.Label7 = tk.Label(top)
        self.Label7.place(relx=0.015, rely=0.416, height=20, width=200)
        self.Label7.configure(activebackground="#f9f9f9")
        self.Label7.configure(activeforeground="black")
        self.Label7.configure(anchor='w')
        self.Label7.configure(background="#ffffff")
        self.Label7.configure(disabledforeground="#a3a3a3")
        self.Label7.configure(font="-family {Arial} -size 10")
        self.Label7.configure(foreground="#000000")
        self.Label7.configure(highlightbackground="#d9d9d9")
        self.Label7.configure(highlightcolor="black")
        self.Label7.configure(justify='left')
        self.Label7.configure(text='''Código do Produto:''')

        self.Label8 = tk.Label(top)
        self.Label8.place(relx=0.015, rely=0.497, height=20, width=199)
        self.Label8.configure(activebackground="#f9f9f9")
        self.Label8.configure(activeforeground="black")
        self.Label8.configure(anchor='w')
        self.Label8.configure(background="#ffffff")
        self.Label8.configure(disabledforeground="#a3a3a3")
        self.Label8.configure(font="-family {Arial} -size 10")
        self.Label8.configure(foreground="#000000")
        self.Label8.configure(highlightbackground="#d9d9d9")
        self.Label8.configure(highlightcolor="black")
        self.Label8.configure(justify='left')
        self.Label8.configure(text='''Descrição do Produto:''')

        self.Label9 = tk.Label(top)
        self.Label9.place(relx=0.015, rely=0.578, height=20, width=200)
        self.Label9.configure(activebackground="#f9f9f9")
        self.Label9.configure(activeforeground="black")
        self.Label9.configure(anchor='w')
        self.Label9.configure(background="#ffffff")
        self.Label9.configure(disabledforeground="#a3a3a3")
        self.Label9.configure(font="-family {Arial} -size 10")
        self.Label9.configure(foreground="#000000")
        self.Label9.configure(highlightbackground="#d9d9d9")
        self.Label9.configure(highlightcolor="black")
        self.Label9.configure(justify='left')
        self.Label9.configure(text='''Data de Inspeção:''')

        self.Label10 = tk.Label(top)
        self.Label10.place(relx=0.015, rely=0.659, height=20, width=199)
        self.Label10.configure(activebackground="#f9f9f9")
        self.Label10.configure(activeforeground="black")
        self.Label10.configure(anchor='w')
        self.Label10.configure(background="#ffffff")
        self.Label10.configure(disabledforeground="#a3a3a3")
        self.Label10.configure(font="-family {Arial} -size 10")
        self.Label10.configure(foreground="#000000")
        self.Label10.configure(highlightbackground="#d9d9d9")
        self.Label10.configure(highlightcolor="black")
        self.Label10.configure(justify='left')
        self.Label10.configure(text='''Comprimento (mm):''')

        self.Label11 = tk.Label(top)
        self.Label11.place(relx=0.015, rely=0.741, height=20, width=199)
        self.Label11.configure(activebackground="#f9f9f9")
        self.Label11.configure(activeforeground="black")
        self.Label11.configure(anchor='w')
        self.Label11.configure(background="#ffffff")
        self.Label11.configure(disabledforeground="#a3a3a3")
        self.Label11.configure(font="-family {Arial} -size 10")
        self.Label11.configure(foreground="#000000")
        self.Label11.configure(highlightbackground="#d9d9d9")
        self.Label11.configure(highlightcolor="black")
        self.Label11.configure(justify='left')
        self.Label11.configure(text='''Diâmetro (mm):''')

        self.Label12 = tk.Label(top)
        self.Label12.place(relx=0.015, rely=0.822, height=20, width=200)
        self.Label12.configure(activebackground="#f9f9f9")
        self.Label12.configure(activeforeground="black")
        self.Label12.configure(anchor='w')
        self.Label12.configure(background="#ffffff")
        self.Label12.configure(disabledforeground="#a3a3a3")
        self.Label12.configure(font="-family {Arial} -size 10")
        self.Label12.configure(foreground="#000000")
        self.Label12.configure(highlightbackground="#d9d9d9")
        self.Label12.configure(highlightcolor="black")
        self.Label12.configure(justify='left')
        self.Label12.configure(text='''Tolerância (mm):''')

        self.txt_nResponsavel = tk.Entry(top)
        self.txt_nResponsavel.place(relx=0.015, rely=0.127, height=27
                , relwidth=0.203)
        self.txt_nResponsavel.configure(background="white")
        self.txt_nResponsavel.configure(disabledforeground="#a3a3a3")
        self.txt_nResponsavel.configure(font="-family {Arial} -size 10")
        self.txt_nResponsavel.configure(foreground="#000000")
        self.txt_nResponsavel.configure(insertbackground="black")
        self.txt_nResponsavel.configure(textvariable=nResponsavel)
        self.txt_nResponsavel.configure(state='normal')

        self.txt_eResponsavel = tk.Entry(top)
        self.txt_eResponsavel.place(relx=0.015, rely=0.208, height=27
                , relwidth=0.203)
        self.txt_eResponsavel.configure(background="white")
        self.txt_eResponsavel.configure(disabledforeground="#a3a3a3")
        self.txt_eResponsavel.configure(font="-family {Arial} -size 10")
        self.txt_eResponsavel.configure(foreground="#000000")
        self.txt_eResponsavel.configure(highlightbackground="#d9d9d9")
        self.txt_eResponsavel.configure(highlightcolor="black")
        self.txt_eResponsavel.configure(insertbackground="black")
        self.txt_eResponsavel.configure(selectbackground="blue")
        self.txt_eResponsavel.configure(selectforeground="white")
        self.txt_eResponsavel.configure(textvariable=eResponsavel)
        self.txt_eResponsavel.configure(state='normal')

        self.txt_nSolicitante = tk.Entry(top)
        self.txt_nSolicitante.place(relx=0.015, rely=0.289, height=27
                , relwidth=0.203)
        self.txt_nSolicitante.configure(background="white")
        self.txt_nSolicitante.configure(disabledforeground="#a3a3a3")
        self.txt_nSolicitante.configure(font="-family {Arial} -size 10")
        self.txt_nSolicitante.configure(foreground="#000000")
        self.txt_nSolicitante.configure(highlightbackground="#d9d9d9")
        self.txt_nSolicitante.configure(highlightcolor="black")
        self.txt_nSolicitante.configure(insertbackground="black")
        self.txt_nSolicitante.configure(selectbackground="blue")
        self.txt_nSolicitante.configure(selectforeground="white")
        self.txt_nSolicitante.configure(textvariable=nSolicitante)
        self.txt_nSolicitante.configure(state='normal')

        self.txt_eSolicitante = tk.Entry(top)
        self.txt_eSolicitante.place(relx=0.015, rely=0.37, height=27
                , relwidth=0.203)
        self.txt_eSolicitante.configure(background="white")
        self.txt_eSolicitante.configure(disabledforeground="#a3a3a3")
        self.txt_eSolicitante.configure(font="-family {Arial} -size 10")
        self.txt_eSolicitante.configure(foreground="#000000")
        self.txt_eSolicitante.configure(highlightbackground="#d9d9d9")
        self.txt_eSolicitante.configure(highlightcolor="black")
        self.txt_eSolicitante.configure(insertbackground="black")
        self.txt_eSolicitante.configure(selectbackground="blue")
        self.txt_eSolicitante.configure(selectforeground="white")
        self.txt_eSolicitante.configure(textvariable=eSolicitante)
        self.txt_eSolicitante.configure(state='normal')

        self.txt_cProduto = tk.Entry(top)
        self.txt_cProduto.place(relx=0.015, rely=0.451, height=27
                , relwidth=0.203)
        self.txt_cProduto.configure(background="white")
        self.txt_cProduto.configure(disabledforeground="#a3a3a3")
        self.txt_cProduto.configure(font="-family {Arial} -size 10")
        self.txt_cProduto.configure(foreground="#000000")
        self.txt_cProduto.configure(highlightbackground="#d9d9d9")
        self.txt_cProduto.configure(highlightcolor="black")
        self.txt_cProduto.configure(insertbackground="black")
        self.txt_cProduto.configure(selectbackground="blue")
        self.txt_cProduto.configure(selectforeground="white")
        self.txt_cProduto.configure(textvariable=cProduto)
        self.txt_cProduto.configure(state='normal')

        self.txt_dProduto = tk.Entry(top)
        self.txt_dProduto.place(relx=0.015, rely=0.532, height=27
                , relwidth=0.203)
        self.txt_dProduto.configure(background="white")
        self.txt_dProduto.configure(disabledforeground="#a3a3a3")
        self.txt_dProduto.configure(font="-family {Arial} -size 10")
        self.txt_dProduto.configure(foreground="#000000")
        self.txt_dProduto.configure(highlightbackground="#d9d9d9")
        self.txt_dProduto.configure(highlightcolor="black")
        self.txt_dProduto.configure(insertbackground="black")
        self.txt_dProduto.configure(selectbackground="blue")
        self.txt_dProduto.configure(selectforeground="white")
        self.txt_dProduto.configure(textvariable=dProduto)
        self.txt_dProduto.configure(state='normal')

        self.txt_dInspecao = tk.Entry(top)
        self.txt_dInspecao.place(relx=0.015, rely=0.614, height=27
                , relwidth=0.203)
        self.txt_dInspecao.configure(background="white")
        self.txt_dInspecao.configure(disabledforeground="#a3a3a3")
        self.txt_dInspecao.configure(font="-family {Arial} -size 10")
        self.txt_dInspecao.configure(foreground="#000000")
        self.txt_dInspecao.configure(highlightbackground="#d9d9d9")
        self.txt_dInspecao.configure(highlightcolor="black")
        self.txt_dInspecao.configure(insertbackground="black")
        self.txt_dInspecao.configure(selectbackground="blue")
        self.txt_dInspecao.configure(selectforeground="white")
        self.txt_dInspecao.configure(textvariable=dInspecao)
        self.txt_dInspecao.configure(state='normal')

        self.txt_Comprimento = tk.Entry(top)
        self.txt_Comprimento.place(relx=0.015, rely=0.695, height=27
                , relwidth=0.203)
        self.txt_Comprimento.configure(background="white")
        self.txt_Comprimento.configure(disabledforeground="#a3a3a3")
        self.txt_Comprimento.configure(font="-family {Arial} -size 10")
        self.txt_Comprimento.configure(foreground="#000000")
        self.txt_Comprimento.configure(highlightbackground="#d9d9d9")
        self.txt_Comprimento.configure(highlightcolor="black")
        self.txt_Comprimento.configure(insertbackground="black")
        self.txt_Comprimento.configure(selectbackground="blue")
        self.txt_Comprimento.configure(selectforeground="white")
        self.txt_Comprimento.configure(textvariable=Comprimento)
        self.txt_Comprimento.configure(state='normal')

        self.txt_Diametro = tk.Entry(top)
        self.txt_Diametro.place(relx=0.015, rely=0.776, height=27
                , relwidth=0.203)
        self.txt_Diametro.configure(background="white")
        self.txt_Diametro.configure(disabledforeground="#a3a3a3")
        self.txt_Diametro.configure(font="-family {Arial} -size 10")
        self.txt_Diametro.configure(foreground="#000000")
        self.txt_Diametro.configure(highlightbackground="#d9d9d9")
        self.txt_Diametro.configure(highlightcolor="black")
        self.txt_Diametro.configure(insertbackground="black")
        self.txt_Diametro.configure(selectbackground="blue")
        self.txt_Diametro.configure(selectforeground="white")
        self.txt_Diametro.configure(textvariable=Diametro)
        self.txt_Diametro.configure(state='normal')

        self.txt_Tolerancia = tk.Entry(top)
        self.txt_Tolerancia.place(relx=0.015, rely=0.857, height=27
                , relwidth=0.203)
        self.txt_Tolerancia.configure(background="white")
        self.txt_Tolerancia.configure(disabledforeground="#a3a3a3")
        self.txt_Tolerancia.configure(font="-family {Arial} -size 10")
        self.txt_Tolerancia.configure(foreground="#000000")
        self.txt_Tolerancia.configure(highlightbackground="#d9d9d9")
        self.txt_Tolerancia.configure(highlightcolor="black")
        self.txt_Tolerancia.configure(insertbackground="black")
        self.txt_Tolerancia.configure(selectbackground="blue")
        self.txt_Tolerancia.configure(selectforeground="white")
        self.txt_Tolerancia.configure(textvariable=Tolerancia)
        self.txt_Tolerancia.configure(state='normal')

        self.rb_Precisao = tk.Radiobutton(top, command=getValue)
        self.rb_Precisao.place(relx=0.505, rely=0.092, relheight=0.031
                , relwidth=0.111)
        self.rb_Precisao.configure(activebackground="#ececec")
        self.rb_Precisao.configure(activeforeground="#000000")
        self.rb_Precisao.configure(background="#ffffff")
        self.rb_Precisao.configure(disabledforeground="#a3a3a3")
        self.rb_Precisao.configure(font="-family {Arial} -size 10")
        self.rb_Precisao.configure(foreground="#000000")
        self.rb_Precisao.configure(highlightbackground="#d9d9d9")
        self.rb_Precisao.configure(highlightcolor="black")
        self.rb_Precisao.configure(justify='left')
        self.rb_Precisao.configure(selectcolor="#ffffffffffff")
        self.rb_Precisao.configure(text='''Alta Precisão''')
        self.rb_Precisao.configure(variable=IHM_support.Vel)
        self.rb_Precisao.configure(value=1)
        self.rb_Precisao.configure(state='normal')
        
        self.rb_Velocidade = tk.Radiobutton(top, command=getValue)
        self.rb_Velocidade.place(relx=0.659, rely=0.092, relheight=0.031
                , relwidth=0.111)
        self.rb_Velocidade.configure(activebackground="#ececec")
        self.rb_Velocidade.configure(activeforeground="#000000")
        self.rb_Velocidade.configure(background="#ffffff")
        self.rb_Velocidade.configure(disabledforeground="#a3a3a3")
        self.rb_Velocidade.configure(font="-family {Arial} -size 10")
        self.rb_Velocidade.configure(foreground="#000000")
        self.rb_Velocidade.configure(highlightbackground="#d9d9d9")
        self.rb_Velocidade.configure(highlightcolor="black")
        self.rb_Velocidade.configure(justify='left')
        self.rb_Velocidade.configure(selectcolor="#ffffffffffff")
        self.rb_Velocidade.configure(text='''Alta Velocidade''')
        self.rb_Velocidade.configure(variable=IHM_support.Vel)
        self.rb_Velocidade.configure(value=2)
        self.rb_Velocidade.configure(state='normal')

        self.pgb_Status = ttk.Progressbar(top)
        self.pgb_Status.place(relx=0.38, rely=0.416, relwidth=0.496
                , relheight=0.0, height=40)
        self.pgb_Status.configure(value=0)

        self.btn_modoOperacao = tk.Button(top, command = Operacao)
        self.btn_modoOperacao.place(relx=0.38, rely=0.681, height=157, width=187)
        self.btn_modoOperacao.configure(activebackground="#ececec")
        self.btn_modoOperacao.configure(activeforeground="#000000")
        self.btn_modoOperacao.configure(background="#00c800")
        self.btn_modoOperacao.configure(disabledforeground="#a3a3a3")
        self.btn_modoOperacao.configure(font="-family {Arial} -size 20")
        self.btn_modoOperacao.configure(foreground="#000000")
        self.btn_modoOperacao.configure(highlightbackground="#d9d9d9")
        self.btn_modoOperacao.configure(highlightcolor="black")
        self.btn_modoOperacao.configure(pady="0")
        self.btn_modoOperacao.configure(text='''Iniciar''')

        self.btn_verTabela = tk.Button(top, command = RunTabela)
        self.btn_verTabela.place(relx=0.555, rely=0.681, height=157, width=187)
        self.btn_verTabela.configure(activebackground="#ececec")
        self.btn_verTabela.configure(activeforeground="#000000")
        self.btn_verTabela.configure(background="#c0c0c0")
        self.btn_verTabela.configure(disabledforeground="#a3a3a3")
        self.btn_verTabela.configure(font="-family {Arial} -size 20")
        self.btn_verTabela.configure(foreground="#000000")
        self.btn_verTabela.configure(highlightbackground="#d9d9d9")
        self.btn_verTabela.configure(highlightcolor="black")
        self.btn_verTabela.configure(pady="0")
        self.btn_verTabela.configure(state='disabled')
        self.btn_verTabela.configure(text='''Ver Tabela''')
        self.btn_verTabela.configure(state="disabled")

        self.btn_verRelatorio = tk.Button(top, command = RunRelatorio)
        self.btn_verRelatorio.place(relx=0.73, rely=0.681, height=157, width=187)
        self.btn_verRelatorio.configure(activebackground="#ececec")
        self.btn_verRelatorio.configure(activeforeground="#000000")
        self.btn_verRelatorio.configure(background="#c0c0c0")
        self.btn_verRelatorio.configure(disabledforeground="#a3a3a3")
        self.btn_verRelatorio.configure(font="-family {Arial} -size 20")
        self.btn_verRelatorio.configure(foreground="#000000")
        self.btn_verRelatorio.configure(highlightbackground="#d9d9d9")
        self.btn_verRelatorio.configure(highlightcolor="black")
        self.btn_verRelatorio.configure(pady="0")
        self.btn_verRelatorio.configure(state='disabled')
        self.btn_verRelatorio.configure(text='''Ver Relatório''')
        self.btn_verRelatorio.configure(state="disabled")

#===================== Execução do programa ====================
if __name__ == '__main__':
    vp_start_gui()