"Programa para teste de escaneamento"
"Sexta-feira - 23 de agosto de 2019"

import pandas as pd
import numpy as np

data = pd.read_csv('[V. 1.0] - Nuvem de pontos (20.08.2019).csv', decimal=",")

from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

x = data['Valor X'].tolist()
y = data['Valor Y'].tolist()
z = data['Valor Z'].tolist()

o = data['AX'].tolist()
p = data['AY'].tolist()
q = data['Valor Z'].tolist()

ax.scatter(x, y, z, c='r', marker='o')
ax.scatter(o, p, q, c='b', marker='x')

ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')

plt.show()