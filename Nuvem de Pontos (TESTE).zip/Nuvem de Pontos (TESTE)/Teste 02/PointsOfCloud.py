"Programa para teste de escaneamento"
"Terça-feira - 21 de janeiro de 2020"

import pandas as pd
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt


df = pd.read_excel('teste.xlsx', decimal=",")
df1 = pd.read_excel('teste3.xlsx', decimal=",")

df1['Cor'] =  df1['Raio Medido'] - df1['Raio Data']

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

x = df['Valor X'].tolist()
y = df['Valor Y'].tolist()
z = df['Valor Z'].tolist()

x1 = df['Valor X'].tolist()
y1 = df['Valor Y'].tolist()
z1 = df['Valor Z'].tolist()

cor = df1['Cor'].tolist()

ax.scatter(x, y, z, c='r', marker='o')
ax.scatter(x1, y1, z1, c=cor, cmap='RdBu', marker='o')

ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')

#plt.show()
